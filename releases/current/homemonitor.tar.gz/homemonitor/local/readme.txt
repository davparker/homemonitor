If you're going to make changes to the default dashbaords and reports, you can place them here so that any upgrades will not effect your custom dashboards. 
